0.0.1 - Test upload <br>
0.1.1 - Updated description and added credits.<br>
0.1.2 - Reupload cause I forgot to edit CHANGELOG <br>
0.1.3 - Attempt at custom behavior, fixed README/CHANGELOG, renamed namespaces ect. <br>
0.1.4 - Fixed NullReferences, Functioning LOS check, added enemy list and base of assigning target (WIP) <br>