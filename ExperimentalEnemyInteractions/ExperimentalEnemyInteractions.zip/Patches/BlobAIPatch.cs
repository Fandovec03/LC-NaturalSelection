﻿using System;
using System.Collections.Generic;
using System.Text;
using HarmonyLib;
using UnityEngine;
using BepInEx;
using BepInEx.Logging;
using System.Runtime.CompilerServices;

namespace ExperimentalEnemyInteractions.Patches
{
	[HarmonyPatch]
	public class BlobAIPatch
	{
	}
}
