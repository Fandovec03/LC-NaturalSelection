# ExperimentalEnemyInteractions 
 Experimental repos for my future enemy interactions mod. Currently it only makes spider hit enemy on collision.

Credits:
--------------------------------------------------
LethalCompany modding discord: <br>
- Zesa, TKronix, Swaggies: helping me figure out collision detection <br>
