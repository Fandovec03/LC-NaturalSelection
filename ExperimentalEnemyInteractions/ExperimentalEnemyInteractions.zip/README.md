# ExperimentalEnemyInteractions 
Experimental mod for my future enemy interactions mod aimed to make the game and it's fauna feel more alive and immersive.<br>
Ever felt like every living being is trying to kill you and everything is stacked agaisnt you? or do you just want to observe the world? __This mod might be for you!__<br>
<br>
Currently supported entities:<br>
- `Bunker Spider`
	- WIP.
- Hygrodere (Blob)
	- Damages creatures that has contact with it with an exception of Maneater. Non-organic and immortal entities are not affected.
- Earth Leviathan<br>
	- Targets creatures that come near it.

Credits:
--------------------------------------------------
Unofficial LethalCompany Discord: <br>
- Zesa, TKronix, Swaggies: helping me figure out collision detection <br>
