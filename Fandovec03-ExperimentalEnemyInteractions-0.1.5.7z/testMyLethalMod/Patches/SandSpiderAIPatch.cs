﻿using System;
using System.Collections.Generic;
using System.Text;
using HarmonyLib;
using UnityEngine;
using BepInEx;
using BepInEx.Logging;
using System.Runtime.CompilerServices;

namespace ExperimentalEnemyInteractions.Patches
{
    [HarmonyPatch(typeof(SandSpiderAI))]
    class SandSpiderAIPatch
    {
        public static List<EnemyAI> enemyList = new List<EnemyAI>();
        static int logInterval = 0;
        static int listInterval = 0;
        static int listInterval2 = 0;
        static int listInterval3 = 0;


        [HarmonyPatch("Update")]
        static void Postfix(SandSpiderAI __instance)
        {
            EnemyAI? targetEnemy = null;
            
            

              /*  switch (__instance.currentBehaviourStateIndex)
            {
                case 0:*/
                if (/*__instance.targetPlayer == null && targetEnemy != null*/true)
                {
                        foreach(EnemyAI enemy in RoundManager.Instance.SpawnedEnemies)
                        {
                                if (enemyList.Contains(enemy) && enemy.isEnemyDead == false)
                                {
                                    //Script.Logger.LogWarning("Found Duplicate " + enemy.gameObject.name + ". Returning;
                                    return; 
                                }
                                if (enemyList.Contains(enemy) && enemy.isEnemyDead == true)
                                {
                                    enemyList.Remove(enemy); 
                                    Script.Logger.LogInfo("Found and removed dead Enemy " + enemy.gameObject.name + " from List. Instance: " + enemy.gameObject.InstanceID());
                                }
                                if (!enemyList.Contains(enemy) && enemy.isEnemyDead == false)
                                {
                                    enemyList.Add(enemy);
                                    Script.Logger.LogMessage("Added " + enemy.gameObject.name + " detected in List. Instance: " + enemy.gameObject.InstanceID());
                                }
                                if (__instance != null)
                                {
                                }
                                /*else
                                {
                                    Script.Logger.LogInfo(__instance);
                                    Script.Logger.LogInfo(enemy);
                                }*/
                        }

                        for (int i = 0; i < enemyList.Count; i++)
                        {
                            if (__instance != null)
                            {
                                RaycastHit hit = new RaycastHit();
                                if (logInterval >= 90)
                                {
                                 Script.Logger.LogInfo(__instance + " triggered listing spawned enemies. Item: " + enemyList[i].gameObject.name);

                                    if (!Physics.Linecast(__instance.gameObject.transform.position, enemyList[i].gameObject.transform.position, out hit, StartOfRound.Instance.collidersRoomMaskDefaultAndPlayers, QueryTriggerInteraction.Ignore))
                                    {
                                        Script.Logger.LogInfo("LOS check: True");
                                    }
                                        logInterval = 0;
                                }

                                if (targetEnemy == null)
                                {
                                    Script.Logger.LogInfo("No enemy assigned. Assigning " + enemyList[i] + " as new targetEnemy.");
                                    targetEnemy = enemyList[i];
                                    return;
                                }
                                if (targetEnemy == enemyList[i])
                                {
                                    Script.Logger.LogWarning( enemyList [i] + " is already assigned as targetEnemy");
                                    return;
                                }
                                if (enemyList != targetEnemy)
                                {
                                    if (Vector3.Distance(__instance.transform.position, enemyList[i].transform.position) < Vector3.Distance(__instance.transform.position, targetEnemy.transform.position))
                                    { 
                                        targetEnemy = enemyList[i];
                                        Script.Logger.LogInfo("Assigned " + enemyList[i] + " as new targetEnemy. Distance: " + Vector3.Distance(__instance.transform.position, targetEnemy.transform.position));
                                        return;
                                    }        
                                }
                            }
                        }
                   /* break;
                case 4:
                    break;*/
                }
        }
    }
}